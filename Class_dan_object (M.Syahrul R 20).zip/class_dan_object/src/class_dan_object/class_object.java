package class_dan_object;

// membuat class sebagai template
class Biodata{
    
    String nama;
    String alamat;
    String tempat_lahir;
    String tanggal_lahir;
    int umur;
    String hobi;
    String sekolah;
    String kelas;
    String program_studi;
    
}

public class class_object {

    public static void main(String[] args) throws Exception{
        
            //membuat object
            Biodata syahrul = new Biodata();
            syahrul.nama = "Mukhamad Syahrul Romadhoni";
            syahrul.alamat = "Pakijangan - Wonorejo";
            syahrul.tempat_lahir = "Pasuruan";
            syahrul.tanggal_lahir = "28-Oktober-2003";
            syahrul.umur = 17;
            syahrul.hobi = "Menggambar";
            syahrul.sekolah ="SMK NEGERI 1 PURWOSARI";
            syahrul.kelas = "XI";
            syahrul.program_studi = "Rekayasa Perangkat Lunak";
            
            //peanggilan
            System.out.println ("BIODATA SAYA");
            System.out.println("Nama Lengkap " +(syahrul.nama));
            System.out.println("Alamat : " +(syahrul.alamat));
            System.out.println("Tempat Lahir: " +(syahrul.tempat_lahir));
            System.out.println("Tanggal Lahir : " +(syahrul.tanggal_lahir));
            System.out.println("Hobi : " +(syahrul.hobi));
            System.out.println("Sekolah : " +(syahrul.sekolah));
            System.out.println("Kelas : " +(syahrul.kelas));
            System.out.println("Program Studi : " +(syahrul.program_studi));
        
    }
    
}